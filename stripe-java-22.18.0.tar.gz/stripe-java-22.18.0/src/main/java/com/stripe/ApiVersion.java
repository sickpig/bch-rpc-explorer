// File generated from our OpenAPI spec
package com.stripe;

final class ApiVersion {
  public static final String CURRENT = "2022-11-15";
}
