// File generated from our OpenAPI spec
package com.stripe.model;

public class ExchangeRateCollection extends StripeCollection<ExchangeRate> {}
