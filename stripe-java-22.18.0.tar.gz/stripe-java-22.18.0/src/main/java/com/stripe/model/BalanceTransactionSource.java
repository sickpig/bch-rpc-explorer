// File generated from our OpenAPI spec
package com.stripe.model;

public interface BalanceTransactionSource extends StripeObjectInterface, HasId {}
