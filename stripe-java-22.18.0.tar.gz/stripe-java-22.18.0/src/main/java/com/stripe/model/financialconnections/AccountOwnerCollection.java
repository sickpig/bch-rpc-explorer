// File generated from our OpenAPI spec
package com.stripe.model.financialconnections;

import com.stripe.model.StripeCollection;

public class AccountOwnerCollection extends StripeCollection<AccountOwner> {}
