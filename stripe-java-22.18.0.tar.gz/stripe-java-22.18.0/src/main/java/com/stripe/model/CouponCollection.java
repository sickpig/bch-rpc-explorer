// File generated from our OpenAPI spec
package com.stripe.model;

public class CouponCollection extends StripeCollection<Coupon> {}
