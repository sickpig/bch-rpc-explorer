// File generated from our OpenAPI spec
package com.stripe.model.identity;

import com.stripe.model.StripeCollection;

public class VerificationSessionCollection extends StripeCollection<VerificationSession> {}
