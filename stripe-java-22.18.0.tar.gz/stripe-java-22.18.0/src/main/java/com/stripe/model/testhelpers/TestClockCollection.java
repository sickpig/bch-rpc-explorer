// File generated from our OpenAPI spec
package com.stripe.model.testhelpers;

import com.stripe.model.StripeCollection;

public class TestClockCollection extends StripeCollection<TestClock> {}
