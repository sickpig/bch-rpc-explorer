// File generated from our OpenAPI spec
package com.stripe.model.billingportal;

import com.stripe.model.StripeCollection;

public class ConfigurationCollection extends StripeCollection<Configuration> {}
