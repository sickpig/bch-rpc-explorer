// File generated from our OpenAPI spec
package com.stripe.model;

public class WebhookEndpointCollection extends StripeCollection<WebhookEndpoint> {}
