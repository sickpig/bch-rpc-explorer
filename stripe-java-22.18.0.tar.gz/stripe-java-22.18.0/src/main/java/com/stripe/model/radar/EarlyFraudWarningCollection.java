// File generated from our OpenAPI spec
package com.stripe.model.radar;

import com.stripe.model.StripeCollection;

public class EarlyFraudWarningCollection extends StripeCollection<EarlyFraudWarning> {}
