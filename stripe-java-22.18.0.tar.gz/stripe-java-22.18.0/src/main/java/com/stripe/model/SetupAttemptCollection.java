// File generated from our OpenAPI spec
package com.stripe.model;

public class SetupAttemptCollection extends StripeCollection<SetupAttempt> {}
