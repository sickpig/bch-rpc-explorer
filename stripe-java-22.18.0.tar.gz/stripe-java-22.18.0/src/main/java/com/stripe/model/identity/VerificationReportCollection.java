// File generated from our OpenAPI spec
package com.stripe.model.identity;

import com.stripe.model.StripeCollection;

public class VerificationReportCollection extends StripeCollection<VerificationReport> {}
