// File generated from our OpenAPI spec
package com.stripe.model.tax;

import com.stripe.model.StripeCollection;

public class TransactionLineItemCollection extends StripeCollection<TransactionLineItem> {}
