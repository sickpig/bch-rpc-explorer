// File generated from our OpenAPI spec
package com.stripe.model;

public interface PaymentSource extends StripeObjectInterface, HasId {}
