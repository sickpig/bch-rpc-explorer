// File generated from our OpenAPI spec
package com.stripe.model.terminal;

import com.stripe.model.StripeCollection;

public class ReaderCollection extends StripeCollection<Reader> {}
