// File generated from our OpenAPI spec
package com.stripe.model.checkout;

import com.stripe.model.StripeCollection;

public class SessionCollection extends StripeCollection<Session> {}
